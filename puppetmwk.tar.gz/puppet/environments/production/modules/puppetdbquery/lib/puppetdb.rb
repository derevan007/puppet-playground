module PuppetDB
  # Current version of this module
  VERSION = [1,4,0]
end
